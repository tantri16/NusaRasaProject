const baseUrl = 'https://www.masakapahariini.com';

module.exports = baseUrl;